# Neural Models: Learning, Depth, Activations, and Output Layers

[![PyTorch](https://img.shields.io/badge/PyTorch-2.0%2B-EE4C2C.svg?style=flat&logo=pytorch)](https://pytorch.org)
[![Python](https://img.shields.io/badge/Python-3.9%2B-3776AB.svg?style=flat&logo=python)](https://python.org)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

An end-to-end laboratory and theoretical study examining the foundations of deep learning:
- **Depth vs. Nonlinearity & The Affine Collapse Problem**
- **Loss-Output Layer Pairings & Information Geometry**
- **Reverse-Mode Automatic Differentiation & Backpropagation**
- **The Symmetry Breaking Problem in Neural Weights**
- **Multi-Class Generalization & Softmax Invariance Diagnostics**

---

## 📁 Repository Structure

```
neural_models_lab/
├── figures/
│   ├── fig1_xor_linear_inseparability.png   # 2D XOR linear non-separability plot
│   ├── fig2_activation_loss_curves.png     # Optimization dynamics (Sigmoid vs Tanh vs ReLU)
│   └── fig3_decision_surfaces.png          # Learned continuous decision contours
├── neural_models_lab.ipynb                 # Interactive Jupyter Notebook (24 structured cells)
├── neural_models_lab.py                    # Standalone executable Python script
├── REPORT.md                               # Formal laboratory report & reflection answers
├── requirements.txt                        # Python dependencies
├── .gitignore                              # Git exclusion rules
└── README.md                               # Project documentation
```

---

## ⚡ Quick Start

### 1. Clone & Set Up Environment
```bash
git clone https://github.com/<your-username>/neural-models-lab.git
cd neural-models-lab

# (Optional) Create virtual environment
python -m venv venv
# Windows:
venv\Scripts\activate
# Linux/macOS:
source venv/bin/activate

pip install -r requirements.txt
```

### 2. Run the Full Experiment Suite
Execute the entire experimental pipeline from the command line:
```bash
python neural_models_lab.py
```

### 3. Open the Interactive Notebook
```bash
jupyter notebook neural_models_lab.ipynb
```

---

## 🔬 Key Laboratory Experiments & Findings

### Task 1: Linear Non-Separability of XOR
XOR requires separating $(0, 1)$ and $(1, 0)$ from $(0, 0)$ and $(1, 1)$. Because the line segment connecting $(0, 1)$ and $(1, 0)$ intersects the line segment connecting $(0, 0)$ and $(1, 1)$ at $(0.5, 0.5)$, their convex hulls overlap. No linear hyperplane can separate them.

<p align="center">
  <img src="figures/fig1_xor_linear_inseparability.png" width="550" alt="XOR Non-Separability"/>
</p>

*Single affine layer result:* The loss stalls at $\ln(2) \approx 0.6931$, producing uninformative probabilities near $0.5$.

---

### Task 2 & 4: Baseline 2-2-1 Model & Activation Comparison
We trained a minimal 2-2-1 architecture ($2 \text{ inputs} \to 2 \text{ hidden units} \to 1 \text{ output}$) across three activation functions under identical seed and optimization settings (Adam, $\eta = 0.05$):

| Hidden Activation | Final BCE Loss | 4/4 Accuracy? | Early $\|\nabla_{W^{(1)}} \mathcal{L}\|_2$ (Step 10) |
| :--- | :---: | :---: | :---: |
| **Sigmoid** | `0.000589` | **100% (4/4)** | `0.000340` |
| **Tanh** | `0.000205` | **100% (4/4)** | `0.018145` |
| **ReLU** | `0.000078` | **100% (4/4)** | `0.005700` |

<p align="center">
  <img src="figures/fig2_activation_loss_curves.png" width="500" alt="Loss Curves"/>
  <img src="figures/fig3_decision_surfaces.png" width="800" alt="Decision Surfaces"/>
</p>

- **Sigmoid:** Exhibits gradient attenuation because $\sigma'(z) \le 0.25$, leading to slower early optimization.
- **Tanh:** Produces the strongest early gradient norm ($0.018145$) due to being zero-centered with $\tanh'(0) = 1.0$.
- **ReLU:** Delivers un-squashed gradients ($f'(z) = 1.0$) and reaches the lowest final loss ($0.000078$), though it requires proper initialization to avoid dead neurons.

---

### Task 4 Part C: The Symmetry Breaking Trap
When all weights and biases are initialized to zero:
$$\delta_1^{(1)} = \delta_2^{(1)} \implies \nabla_{W_1^{(1)}} \mathcal{L} = \nabla_{W_2^{(1)}} \mathcal{L}$$
Both rows receive mathematically identical updates at every gradient step:
```
Step 1: Row 0 == Row 1? True
Step 2: Row 0 == Row 1? True
Step 3: Row 0 == Row 1? True
Step 4: Row 0 == Row 1? True
Step 5: Row 0 == Row 1? True
```
Because the two units never differentiate into distinct features, the network effectively functions as a single neuron and fails XOR. **Random weight initialization is strictly required.**

---

### Task 5: 3-Class Sensor State Extension
We extended the problem into a three-state classification task:
- **Class 0:** $(0, 0)$ [both inactive]
- **Class 1:** $(0, 1)$ or $(1, 0)$ [sensors disagree]
- **Class 2:** $(1, 1)$ [both active]

Using a 2-2-3 architecture with Softmax and Cross-Entropy:
- Output matrix shape: $W^{(2)} \in \mathbb{R}^{3 \times 2}$.
- Logit error gradient: $\nabla_z \mathcal{L} = p - y$.
- Softmax numerical shift invariance verified: adding $+100$ to all logits produces a maximum probability difference of $1.16 \times 10^{-10}$ (floating-point precision limit).

---

## 📖 Complete Lab Report & Answers

For full mathematical proofs, derivation of $\nabla_z \mathcal{L} = p - y$, and in-depth answers to all 7 reflection questions, see [`REPORT.md`](REPORT.md).

---

## 📜 License
This project is licensed under the MIT License - see the LICENSE file for details.
